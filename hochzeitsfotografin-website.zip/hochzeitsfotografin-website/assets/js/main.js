const header = document.querySelector('[data-header]');
const nav = document.querySelector('[data-nav]');
const navToggle = document.querySelector('[data-nav-toggle]');
const year = document.querySelector('[data-year]');
const reveals = document.querySelectorAll('.reveal');
const form = document.querySelector('[data-contact-form]');
const formNote = document.querySelector('[data-form-note]');

year.textContent = new Date().getFullYear();

const setHeader = () => {
  header.classList.toggle('is-scrolled', window.scrollY > 24);
};
setHeader();
window.addEventListener('scroll', setHeader, { passive: true });

navToggle.addEventListener('click', () => {
  const isOpen = nav.classList.toggle('is-open');
  navToggle.setAttribute('aria-expanded', String(isOpen));
});

nav.querySelectorAll('a').forEach((link) => {
  link.addEventListener('click', () => {
    nav.classList.remove('is-open');
    navToggle.setAttribute('aria-expanded', 'false');
  });
});

const observer = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      entry.target.classList.add('is-visible');
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.14 });

reveals.forEach((el) => observer.observe(el));

form.addEventListener('submit', (event) => {
  const action = form.getAttribute('action') || '';
  if (action.includes('DEINE-ID')) {
    event.preventDefault();
    const data = new FormData(form);
    const subject = encodeURIComponent('Hochzeitsanfrage über die Website');
    const body = encodeURIComponent(
      `Name: ${data.get('name') || ''}\nE-Mail: ${data.get('email') || ''}\nDatum: ${data.get('date') || ''}\nLocation: ${data.get('location') || ''}\n\nNachricht:\n${data.get('message') || ''}`
    );
    window.location.href = `mailto:hello@maison-amour.at?subject=${subject}&body=${body}`;
    formNote.textContent = 'Dein E-Mail-Programm wurde geöffnet. Für direkten Versand bitte eine Formspree-ID eintragen.';
  }
});
